import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';


@Component({
    templateUrl:'./editor.component.html',
    styleUrls:['./editor.component.css']
})
export class RevenueEditor implements OnInit
{
    private dealForm: FormGroup;
    private date:FormControl;
    private value:FormControl;
    private comment:FormControl;

    private rdate:string;
    private rvalue:number;
    private rcomment:string;

    constructor(private route:ActivatedRoute, private formBuilder:FormBuilder)
    {
        this.date = new FormControl( '', [Validators.required, Validators.pattern('[0-9]{10}')]);
        this.value = new FormControl( '', [Validators.required]);
        this.comment = new FormControl( '', [Validators.required, Validators.pattern('[A-za-z0-9]{5,150}')]);

        this.dealForm=formBuilder.group({
         date :this.date,
         value:this.value,
         comment:this.comment
        })
    }

    ngOnInit()
    {
        this.route.params.subscribe(  param=>{
            console.log(param);
         //   this.date =param.this.
         this.rdate =param.p1;
         this.rvalue = param.p2;
        this.rcomment = param.p3;
        })
      // console.log ( this.route.snapshot.params);
    }

}