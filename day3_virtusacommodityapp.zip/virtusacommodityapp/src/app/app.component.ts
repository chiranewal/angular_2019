
import {Component} from "@angular/core";

//<commodity-app></commodity-app>
@Component({
    selector: 'commodity-app',
    templateUrl: './app.component.html',
    styleUrls:['./app.component.css']
})
export class AppComponent
{
    //field 
    private logoPath:string; 
    constructor()
    {
        this.logoPath = "./assets/logo.png";
    }
}