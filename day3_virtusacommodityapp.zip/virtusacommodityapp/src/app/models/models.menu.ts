export class ModelsMenu
{
  get icon(): string {
    return this._icon;
  }

  set icon(value: string) {
    this._icon = value;
  }
  private _label:string;
  private _icon:string;
  public routerLink:object[];

  private _items:Item[]

  constructor(plabel:string,picon:string,prouter:object[], pitems:Item[])
  {

    this._label=plabel;
    this._icon=picon;
    this._items=pitems;
    this.routerLink=prouter;
  }

  get items(): Item[] {
    return this._items;
  }

  set items(value: Item[]) {
    this._items = value;
  }
  get label(): string {
    return this._label;
  }

  set label(value: string) {
    this._label = value;
  }




}




export class Item
{
  private _label:string;
  private _icon:string;
  public routerLink:object[];

  
  constructor(plabel,picon, prouter)
  {
    this._label=plabel;
    this._icon=picon;
    this.routerLink = prouter;
  }


  get icon(): string {
    return this._icon;
  }

  set icon(value: string) {
    this._icon = value;
  }


  get label(): string {
    return this._label;
  }

  set label(value: string) {
    this._label = value;
  }





}


