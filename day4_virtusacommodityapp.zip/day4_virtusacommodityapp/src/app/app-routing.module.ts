import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { RevenueEditor } from './editor/editor.component';
import { RevenueReporting } from './reporter/reporter.component';
import { AuthGuardService } from './services/service.authguard';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {
   // path:'Login',
    path:'',
    component:LoginComponent,
    outlet:'LoginOutlet'
  },
  {
    path:'RevenueEditor/:p1/:p2/:p3', 
    component:RevenueEditor,
    outlet:'REOutlet', 
  },
  {
    path:'RevenueEditor', 
    component:RevenueEditor,
    outlet:'REOutlet', 
      canActivate: [AuthGuardService]

  },
  {
    path:'RevenueReporting',
    component:RevenueReporting,
    outlet:'RROutlet',
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
