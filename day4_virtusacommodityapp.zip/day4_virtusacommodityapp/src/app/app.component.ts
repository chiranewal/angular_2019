
import {Component, OnInit} from "@angular/core";
import { Router } from '@angular/router';

//<commodity-app></commodity-app>
@Component({
    selector: 'commodity-app',
    templateUrl: './app.component.html',
    styleUrls:['./app.component.css']
})
export class AppComponent implements OnInit
{
    //field 
    public logoPath:string; 
    constructor( public router: Router)
    {
        this.logoPath = "./assets/logo.png";
    }
    ngOnInit()
    {
        this.router.navigate( ['']);
    }
}

