import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { MenubarModule} from 'primeng/menubar';
import { ServicesMenu } from './services/services.menu';
import { RevenueEditor } from './editor/editor.component';
import { RevenueReporting } from './reporter/reporter.component';
import {TabViewModule} from 'primeng/tabview'
import { ServicesDeal } from './services/services.deal';
import { HttpClientModule } from '@angular/common/http';
import { DealsComponent } from './deals/deals.component.';
import { MatSortModule, MatTableModule, MatPaginatorModule, MatButtonModule, MatDialogModule, MatInputModule, MatFormFieldModule, MatIconModule } from '@angular/material';
import { CommentComponent } from './comment/comment.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './services/service.authguard';
import { AuthService } from './services/service.authenticationservice';
import { PasswordValidator } from './login/passwordvalidator.directive';
import { DealsFilterComponent } from './deals/deals.filtercomponent';
@NgModule({
  declarations: [
    AppComponent,
    MenuComponent, 
    RevenueEditor,
    RevenueReporting,
    DealsComponent,
    CommentComponent,
    LoginComponent,
    PasswordValidator,
    DealsFilterComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MenubarModule,
    TabViewModule,
    HttpClientModule,
    MatSortModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    BrowserAnimationsModule,
    MatDialogModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    
  ],
  providers: [ServicesMenu,ServicesDeal,AuthGuardService, AuthService],
  entryComponents:[CommentComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
