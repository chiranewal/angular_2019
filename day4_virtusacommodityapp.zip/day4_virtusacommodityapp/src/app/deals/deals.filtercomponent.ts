import { PipeTransform } from '@angular/core';
import { Pipe } from '@angular/core';

@Pipe({name:"DealFilter"})
export class DealsFilterComponent implements PipeTransform {
   // transform(value: any, ...args: any[]) {
    transform(value: any, filterValue:string):any {
      //  throw new Error("Method not implemented.");
      return value.filter( obj=> obj[1]> filterValue)
    }
}