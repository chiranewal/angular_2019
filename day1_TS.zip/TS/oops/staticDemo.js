var Grid = /** @class */ (function () {
    function Grid() {
    }
    Grid.origin = { x: 0, y: 0 };
    return Grid;
}());
function foo(a, b) {
    return a + b;
}
//let a = foo.apply( undefined, [10]);
//console.log(a);
//let b = foo.apply( undefined, [10,20]);
//console.log(b);
var c = foo.apply(undefined, [10, "hello", 30]);
var d = foo.apply(undefined, [10, "hello"]);
console.log(c);
console.log(d);
// tsc --strictBindCallApply
