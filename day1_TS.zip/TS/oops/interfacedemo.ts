interface labelledValue{
    label?:string;
    color?:string;
}

function printLabel( lvlObj: labelledValue) {
    console.log(lvlObj.label);
    console.log(lvlObj.color);

}

let myObj = {color:"red"};
//let myObj = {size:10};
printLabel(myObj);

interface Accounts
{
    actid:number;
   acttype?:string;
}

function accessAccount( account:Accounts)
{
    console.log( account.acttype);
    console.log( account.actid);
}

//let obji2= {actid:120, acttype:"savings"};
let obji2= {actid:120};
accessAccount(obji2);

// READ ONLY 

interface FixedDeposit {
    x : number;
    SI:Function;
    transaction(time:Date): Function;
}


class SBIFD implements FixedDeposit
{
    SI(){
        console.log("SI Called");
    }
    transaction(time:Date)
    {
        console.log( time);
    }
    constructor( public x:number, public SI:Function, public transaction:Function ){

    }

}

//var obj = new SBIFD( 123,  )