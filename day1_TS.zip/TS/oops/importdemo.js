"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//import {PriviledgedMember} from './fieldsandprop'
var fieldsandprop_1 = require("./fieldsandprop");
var obj = new fieldsandprop_1.EliteClub.PrivilegedMember(2544, 'santosh');
obj.memberInfo();
