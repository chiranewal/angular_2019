//import {PriviledgedMember} from './fieldsandprop'
import {EliteClub} from './fieldsandprop'


let obj:EliteClub.PrivilegedMember = new EliteClub.PrivilegedMember(2544, 'santosh');
obj.memberInfo();
