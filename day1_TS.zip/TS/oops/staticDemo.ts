class Grid {
    static origin = {x:0, y:0};
}

function foo( a:number, b:string){
    return a+b;
}

//let a = foo.apply( undefined, [10]);
//console.log(a);
//let b = foo.apply( undefined, [10,20]);
//console.log(b);
let c = foo.apply( undefined, [10, "hello",30]);
let d = foo.apply( undefined, [10, "hello"]);
console.log(c);
console.log(d);
// tsc --strictBindCallApply