let users=[{ id:1, 
name: 'Vivek'}];
users.forEach(obj => {
    console.log(obj);
});