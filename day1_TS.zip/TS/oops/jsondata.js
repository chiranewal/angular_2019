var users = [{ id: 1,
        name: 'Vivek' }];
users.forEach(function (obj) {
    console.log(obj);
});
