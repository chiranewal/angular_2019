class Member
{
    //fields
    protected _id:number;
    protected  _name:string;
    public  _location:string;

    ///properties 
 /*   get id():number
    {
        return this._id;
    }
    set id(value:number)
    {
        this._id = value;
    } 
    get name():string
    {
        return this._name;
    }
    set name(name:string)
    {
        this._name = name;
    }*/
    public get location():string{
        return this._location;
    }
    public set location(value: string){
        this._location = value;
    }
    constructor( id:number, name:string){
        this._id = id;
        this._name = name;
    }
}

//let  memberObj:Member = new Member();
//memberObj.name = "Vivek";
//memberObj.id  = 10;
///console.log (memberObj);

// Inheritance 

export class PrivilegedMember extends Member 
{
    private _offer:number;

    constructor(id:number, name:string){
        super(id, name);
       // this._id = id;
       // this._name = name;
    }
    public get offer():number{
        return this._offer;
    }
    public set offer(value: number){
        this._offer = value;
    }
    public memberInfo():void{
        let info = `member id =${this._id},'name='${this._name}`
    }
}

//let privObj = new PrivilegedMember(48, "Anirudh");
//privObj.location = "Chennai";
//console.log(privObj);

