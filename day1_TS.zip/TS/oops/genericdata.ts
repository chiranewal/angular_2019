//Generic Class

class Template<T>
{
    data: T;
    compute: (data1:T)
}


var obj = new Template<number>();
obj.compute()