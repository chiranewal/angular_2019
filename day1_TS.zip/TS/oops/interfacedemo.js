function printLabel(lvlObj) {
    console.log(lvlObj.label);
    console.log(lvlObj.color);
}
var myObj = { color: "red" };
//let myObj = {size:10};
printLabel(myObj);
function accessAccount(account) {
    console.log(account.acttype);
    console.log(account.actid);
}
//let obji2= {actid:120, acttype:"savings"};
var obji2 = { actid: 120 };
accessAccount(obji2);
var SBIFD = /** @class */ (function () {
    function SBIFD(x, SI, transaction) {
        this.x = x;
        this.SI = SI;
        this.transaction = transaction;
    }
    SBIFD.prototype.SI = function () {
        console.log("SI Called");
    };
    SBIFD.prototype.transaction = function (time) {
        return new Date();
    };
    return SBIFD;
}());
//var obj = new SBIFD( 123,  )
