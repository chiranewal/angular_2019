let firstname:string;

let flag:boolean;
let id: number;
firstname = 'Parameter1';
flag = true;
id=90;
console.log("First Name \t" + firstname);
console.log("Status \t" + id);
var loanNo :Number;
// USe BACK QUOTE 
let info:any= `I am ${firstname} having ${id} is active`;
console.log(info);
info =23;

/// INTRODUCING  ENUMS
enum genderTypes{MALE, FEMALE};


let gender:string =genderTypes[1];
console.log("Gender:" + gender);
let gend:genderTypes;
gend=genderTypes.FEMALE;

console.log("Gend" + genderTypes[gend]);

/// ANY
let customer:any;
customer={
    id:1234,
    name:"Santhosh",
    address: "chennai",
    status: true
}

console.log( customer);
console.log (customer.address);

// ARRAYS 
let list:number[] = [1,2,3];

//ARROW function 
let branches:string[] = ["Pune:", "Bangalore", "Chennai"];

branches.forEach(element => {
    console.log(element);
});

// FUNCTION : default parameter wirh return type 

function customerdata( name:string, country: string="India"):string{
console.log(name, "=>", country);
return name + "=>" + country;
}
console.log (customerdata("Anil") );
console.log ( customerdata("Anoop", "USA"));

// REST PARAMETERS - FuNCTION 

function employeedata(id:number, name:string, ...skillset){
    skillset.forEach(skill=>{
        console.log(skill);
    })
}

employeedata(10, "Vivek", "C", "Java", "Ang");
employeedata(10, "Vivek2", 3);

function error(message:string):never {
    throw new Error(message);
}


error(" This is error message");
