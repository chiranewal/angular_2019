class PubAnimal{
    prri
}