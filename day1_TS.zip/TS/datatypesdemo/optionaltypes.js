var firstname;
var flag;
var id;
firstname = 'Parameter1';
flag = true;
id = 90;
console.log("First Name \t" + firstname);
console.log("Status \t" + id);
var loanNo;
// USe BACK QUOTE 
var info = "I am " + firstname + " having " + id + " is active";
console.log(info);
info = 23;
/// INTRODUCING  ENUMS
var genderTypes;
(function (genderTypes) {
    genderTypes[genderTypes["MALE"] = 0] = "MALE";
    genderTypes[genderTypes["FEMALE"] = 1] = "FEMALE";
})(genderTypes || (genderTypes = {}));
;
var gender = genderTypes[1];
console.log("Gender:" + gender);
var gend;
gend = genderTypes.FEMALE;
console.log("Gend" + genderTypes[gend]);
/// ANY
var customer;
customer = {
    id: 1234,
    name: "Santhosh",
    address: "chennai",
    status: true
};
console.log(customer);
console.log(customer.address);
// ARRAYS 
var list = [1, 2, 3];
//ARROW function 
var branches = ["Pune:", "Bangalore", "Chennai"];
branches.forEach(function (element) {
    console.log(element);
});
// FUNCTION : default parameter wirh return type 
function customerdata(name, country) {
    if (country === void 0) { country = "India"; }
    console.log(name, "=>", country);
    return name + "=>" + country;
}
console.log(customerdata("Anil"));
console.log(customerdata("Anoop", "USA"));
// REST PARAMETERS - FuNCTION 
function employeedata(id, name) {
    var skillset = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        skillset[_i - 2] = arguments[_i];
    }
    skillset.forEach(function (skill) {
        console.log(skill);
    });
}
employeedata(10, "Vivek", "C", "Java", "Ang");
employeedata(10, "Vivek2", 3);
function error(message) {
    throw new Error(message);
}
error(" This is error message");
