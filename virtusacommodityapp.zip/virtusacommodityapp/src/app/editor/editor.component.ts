import { Component } from '@angular/core';


@Component({
    templateUrl:'./editor.component.html',
    styleUrls:['./editor.component.css']
})
export class RevenueEditor{

}