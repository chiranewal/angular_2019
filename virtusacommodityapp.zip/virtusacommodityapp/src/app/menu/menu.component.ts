import { Component, OnInit } from '@angular/core';
import { ServicesMenu } from '../services/services.menu';

@Component({
  selector: 'commodity-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit{
  private _items:any
  constructor ( private serviceObj: ServicesMenu)
  {

  }

  ngOnInit(){
    this._items = this.serviceObj.getMenuItems();
  }

}
