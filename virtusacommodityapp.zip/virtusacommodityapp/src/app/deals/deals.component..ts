import { Component } from "@angular/core";
import { OnInit } from '@angular/core';
import { ServicesDeal } from '../services/services.deal';

@Component({
    selector:'deal-data',
    templateUrl:'./deals.component.html',
    styleUrls:['./deals.component.css']
})

export class DealsComponent implements OnInit{
    constructor(private servicesDeal: ServicesDeal)
    {

    }
    ngOnInit()
    {
        this.servicesDeal.getDeals().subscribe(  response=> {
            
        })
    }
}