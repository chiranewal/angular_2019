import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { MenubarModule} from 'primeng/menubar';
import { ServicesMenu } from './services/services.menu';
import { RevenueEditor } from './editor/editor.component';
import { RevenueReporting } from './reporter/reporter.component';
import {TabViewModule} from 'primeng/tabview'
import { ServicesDeal } from './services/services.deal';
import { HttpClientModule } from '@angular/common/http';
import { DealsComponent } from './deals/deals.component.';
@NgModule({
  declarations: [
    AppComponent,
    MenuComponent, 
    RevenueEditor,
    RevenueReporting,
    DealsComponent
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MenubarModule,
    TabViewModule,
    HttpClientModule
  ],
  providers: [ServicesMenu,ServicesDeal],
  bootstrap: [AppComponent]
})
export class AppModule { }
