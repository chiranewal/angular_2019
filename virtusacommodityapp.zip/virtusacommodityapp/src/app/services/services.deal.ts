import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class ServicesDeal
{
    constructor(private http:HttpClient)
    {

    }

    getDeals():Observable<any>
    {
       return  this.http.get("https://www.quandl.com/api/v3/datasets/OPEC/ORB.json");
    }
}