import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { RevenueEditor } from './editor/editor.component';
import { RevenueReporting } from './reporter/reporter.component';

const routes: Routes = [
  {
    path:'RevenueEditor', 
    component:RevenueEditor,
    outlet:'REOutlet'

  },
  {
    path:'RevenueReporting',
    component:RevenueReporting,
    outlet:'RROutlet'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
